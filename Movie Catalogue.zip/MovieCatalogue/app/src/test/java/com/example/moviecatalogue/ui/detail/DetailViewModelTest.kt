package com.example.moviecatalogue.ui.detail


import com.example.moviecatalogue.utils.DataDummy
import junit.framework.Assert
import junit.framework.Assert.assertEquals
import junit.framework.Assert.assertNotNull
import org.junit.Before
import org.junit.Test

class DetailViewModelTest{
    private lateinit var viewModel: DetailViewModel
    private val dummyFilm = DataDummy.generateDummyMovie()[0]
    private val title = dummyFilm.title

    @Before
    fun setUp(){
        viewModel = DetailViewModel()
        viewModel.setDetail(title,"extra_movie")
    }

    @Test
    fun getMovie(){
        viewModel.setDetail(dummyFilm.title,"extra_movie")
        val detail = viewModel.getDetail()
        assertNotNull(detail)
        assertEquals(detail.date, dummyFilm.date)
        assertEquals(detail.description, dummyFilm.description)
        assertEquals(detail.genre, dummyFilm.genre)
        assertEquals(detail.image, dummyFilm.image)
        assertEquals(detail.pemain, dummyFilm.pemain)
        assertEquals(detail.title, dummyFilm.title)
        assertEquals(detail.url, dummyFilm.url)
    }
}