package com.example.moviecatalogue.ui.home.viewmodel

import junit.framework.Assert.assertEquals
import junit.framework.Assert.assertNotNull
import org.junit.Before
import org.junit.Test

class TvShowsViewModelTest {
    private lateinit var viewModel: TvShowsViewModel

    @Before
    fun setUp(){
        viewModel = TvShowsViewModel()
    }

    @Test
    fun getTvShows(){
        val tvShows = viewModel.getTvShows()
        assertNotNull(tvShows)
        assertEquals(10, tvShows.size)
    }
}