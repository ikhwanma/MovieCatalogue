package com.example.moviecatalogue.ui.home.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.moviecatalogue.data.Film
import com.example.moviecatalogue.data.source.FilmRepository
import com.example.moviecatalogue.utils.DataDummy
import com.loopj.android.http.AsyncHttpClient
import com.loopj.android.http.AsyncHttpResponseHandler
import cz.msebera.android.httpclient.Header
import org.json.JSONObject

class TvShowsViewModel(private val filmRepository: FilmRepository) : ViewModel() {
    /*private val _listTvShows = MutableLiveData<ArrayList<Film>>()
    val listTvShows: LiveData<ArrayList<Film>> = _listTvShows*/

    fun getTvShows(): LiveData<List<Film>> = filmRepository.getAllTvShows()

    /*fun getTvShowsApi(){
        val client = AsyncHttpClient()
        val url = "https://api.themoviedb.org/3/tv/popular?api_key=63be5170b074455a7fba3a528aeea4ce"
        client.get(url, object : AsyncHttpResponseHandler() {
            override fun onSuccess(
                statusCode: Int,
                headers: Array<out Header>,
                responseBody: ByteArray
            ) {
                val result = String(responseBody)
                val listTvShows = ArrayList<Film>()
                try {
                    val jsonObject = JSONObject(result)
                    val jsonArray = jsonObject.getJSONArray("results")
                    for (i in 0 until jsonArray.length()){
                        val jsonObject1 = jsonArray.getJSONObject(i)
                        var imgUrl = "https://image.tmdb.org/t/p/w500${jsonObject1.getString("poster_path")}"
                        val film = Film()
                        film.image = imgUrl
                        val title = jsonObject1.getString("original_name")
                        val date = jsonObject1.getString("first_air_date")
                        film.title = title
                        film.date = date
                        listTvShows.add(film)
                    }
                    _listTvShows.value = listTvShows
                }catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            override fun onFailure(
                statusCode: Int,
                headers: Array<out Header>?,
                responseBody: ByteArray?,
                error: Throwable?
            ) {
                TODO("Not yet implemented")
            }

        })
    }*/
}