package com.example.moviecatalogue.ui.home.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.moviecatalogue.data.Film
import com.example.moviecatalogue.data.source.FilmRepository
import com.example.moviecatalogue.utils.DataDummy
import com.loopj.android.http.AsyncHttpClient
import com.loopj.android.http.AsyncHttpResponseHandler
import cz.msebera.android.httpclient.Header
import org.json.JSONArray
import org.json.JSONObject

class MovieViewModel(private val filmRepository: FilmRepository): ViewModel() {

    fun getMovie(): LiveData<List<Film>> = filmRepository.getAllMovie()

}