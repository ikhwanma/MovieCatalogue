package com.example.moviecatalogue.ui.detail

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.moviecatalogue.data.Film
import com.example.moviecatalogue.data.source.FilmRepository
import com.example.moviecatalogue.utils.DataDummy

class DetailViewModel(private val filmRepository: FilmRepository): ViewModel() {
    private lateinit var title: String
    private lateinit var jenis: String

    fun setDetail(title:String, jenis:String){
        this.title = title
        this.jenis = jenis
    }
    fun getDetail(): Film{
        lateinit var film:Film
        if (jenis == DetailActivity.EXTRA_MOVIE){
            val movie = filmRepository.getAllMovie()
            for (f in movie){
                if (f.title == title) film = f
            }
        }else {
            val tvShows = filmRepository.getAllTvShows()
            for (f in tvShows) if (f.title == title) film = f
        }
        return film
    }
}