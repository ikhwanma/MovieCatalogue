package com.example.moviecatalogue.data.source

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.moviecatalogue.data.Film
import com.example.moviecatalogue.data.source.remote.RemoteDataSource
import com.example.moviecatalogue.data.source.remote.response.FilmResponse

class FilmRepository private constructor(private val remoteDataSource: RemoteDataSource) : FilmDataSource{
    companion object {
        @Volatile
        private var instance: FilmRepository? = null
        fun getInstance(remoteData: RemoteDataSource): FilmRepository =
            instance ?: synchronized(this) {
                instance ?: FilmRepository(remoteData).apply { instance = this }
            }
    }

    override fun getAllMovie(): LiveData<List<Film>> {
        val movieResult = MutableLiveData<List<Film>>()
        remoteDataSource.getAllMovie(object : RemoteDataSource.LoadMovieCallback{
            override fun onAllMovieReceived(movieResponses: List<FilmResponse>) {
                val movieList = ArrayList<Film>()
                for (response in movieResponses){
                    val movie = Film(
                        response.title,
                        response.image,
                        response.date,
                        response.description,
                        response.pemain,
                        response.genre,
                        response.url
                    )
                    movieList.add(movie)
                }
                movieResult.postValue(movieList)
            }

        })

        return movieResult
    }

    override fun getAllTvShows(): LiveData<List<Film>> {
        val tvShowsResult = MutableLiveData<List<Film>>()
        remoteDataSource.getAllTvShows(object : RemoteDataSource.LoadTvShowsCallback{
            override fun onAllTvShowsReceived(tvShowsResponses: List<FilmResponse>) {
                val tvShowsList = ArrayList<Film>()
                for (response in tvShowsResponses){
                    val tvShows = Film(
                        response.title,
                        response.image,
                        response.date,
                        response.description,
                        response.pemain,
                        response.genre,
                        response.url
                    )
                    tvShowsList.add(tvShows)
                }
                tvShowsResult.postValue(tvShowsList)
            }
        })
        return tvShowsResult
    }

}