package com.example.moviecatalogue.data.source

import androidx.lifecycle.LiveData
import com.example.moviecatalogue.data.Film

interface FilmDataSource {
    fun getAllMovie(): LiveData<List<Film>>
    fun getAllTvShows(): LiveData<List<Film>>
}